#
# run unittests
#

if which xbcloud-t ; then
    run_cmd xbcloud-t
fi
